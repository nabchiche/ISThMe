
;;*********************************************************
;; ISTHME: Illustration de stratégies de thérapeutique médicale
;; Version 1.0.c
;; Date : 22 mai 2012

;; Version ISM_1.0.c dans laquelle un traitement est conservé si la valeur de PAS est inférieure à un seuil cible

(1) Ajout d'une condition à toutes les règles de prescription:  && (cible_atteinte == F)

(2) Ajout d'une règle de prescription prescript_1.11 qui se déclenche si: "SI la cible est atteinte, le traitement courant est conservé" 

(3) modification du cycle d'un individu par l'ajout d'une étape controle après l'étape de mesure. Création d'un fichier regle_controle.clp